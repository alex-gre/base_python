#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""This module provides RP Contacts entry point script."""

from contacts.main import main

if __name__ == "__main__":
    main()