# Импорт библиотеки'
import sqlite3
 
conn = sqlite3.connect("employees.db")
cursor = conn.cursor()
    # Создание таблицы
cursor.execute('CREATE TABLE IF NOT EXISTS employee_data (emp_id integer PRIMARY KEY AUTOINCREMENT,f_name text,\
              l_name text,title text,age int,salary int,email text)')
               
conn.commit()
     # Вводим данные
   
f_name = input('Enter First Name: ')
l_name = input('Enter Last Name: ')
title = input('Title: ')
age = int(input('Enter Age:'))
salary = int(input('Enter Salary:'))
email = input('Enter Email: ')
    # Вставляем данные в таблицу
cursor.execute('''INSERT INTO employee_data(f_name,l_name,title,age,salary,email) VALUES (?,?,?,?,?,?)''',(f_name,l_name,title,age,salary,email))
                                                                                                                  
conn.commit()
    # Сохраняем изменения
conn.commit()
cursor.close()
conn.close()
