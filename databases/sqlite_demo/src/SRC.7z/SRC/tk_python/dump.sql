PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE employee_data
	(
        emp_id  integer PRIMARY KEY AUTOINCREMENT,
 	f_name varchar(20),
 	l_name varchar(20),
	title varchar(30),
	age int,
	yos int,
	salary int,
	perks int,
	email varchar(60)
	);
INSERT INTO "employee_data" VALUES(1,'John','Hagan','Senior Programmer',32,4,120000,25000,'john_hagan@bignet.com');
INSERT INTO "employee_data" VALUES(2,'Ganesh','Pillai','Senior Programmer',32,4,110000,20000,'g_pillai@bignet.com');
INSERT INTO "employee_data" VALUES(3,'Anamika','Pandit','Web Designer',27,3,90000,15000,'ana@bignet.com');
INSERT INTO "employee_data" VALUES(4,'Mary','Anchor','Web Designer',26,2,85000,15000,'mary@bignet.com');
INSERT INTO "employee_data" VALUES(5,'Fred','Kruger','Programmer',31,3,75000,15000,'fk@bignet.com');
INSERT INTO "employee_data" VALUES(6,'John','MacFarland','Programmer',34,4,80000,16000,'john@bignet.com');
INSERT INTO "employee_data" VALUES(7,'Edward','Sakamuro','Programmer',25,2,75000,14000,'eddie@bignet.com');
INSERT INTO "employee_data" VALUES(8,'Alok','Nanda','Programmer',32,3,70000,10000,'alok@bignet.com');
INSERT INTO "employee_data" VALUES(9,'Hassan','Rajabi','Multimedia Programmer',33,3,90000,15000,'hasan@bignet.com');
INSERT INTO "employee_data" VALUES(10,'Paul','Simon','Multimedia Programmer',43,2,85000,12000,'ps@bignet.com');
INSERT INTO "employee_data" VALUES(11,'Arthur','Hoopla','Multimedia Programmer',32,1,75000,15000,'arthur@bignet.com');
INSERT INTO "employee_data" VALUES(12,'Kim','Hunter','Senior Web Designer',32,2,110000,20000,'kim@bignet.com');
INSERT INTO "employee_data" VALUES(13,'Roger','Lewis','System Administrator',35,2,100000,13000,'roger@bignet.com');
INSERT INTO "employee_data" VALUES(14,'Danny','Gibson','System Administrator',34,1,90000,12000,'danny@bignet.com');
INSERT INTO "employee_data" VALUES(15,'Mike','Harper','Senior Marketing Executive',36,2,120000,28000,'mike@bignet.com');
INSERT INTO "employee_data" VALUES(16,'Monica','Sehgal','Marketing Executive',30,3,90000,25000,'monica@bignet.com');
INSERT INTO "employee_data" VALUES(17,'Hal','Simlai','Marketing Executive',27,2,70000,18000,'hal@bignet.com');
INSERT INTO "employee_data" VALUES(18,'Joseph','Irvine','Marketing Executive',27,2,72000,18000,'joseph@bignet.com');
INSERT INTO "employee_data" VALUES(19,'Shahida','Ali','Customer Service Manager',32,3,70000,9000,'shahida@bignet.com');
INSERT INTO "employee_data" VALUES(20,'Peter','Champion','Finance Manager',36,4,120000,25000,'peter@bignet.com');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('employee_data',20);
COMMIT;
