rip  data post button <view data> onclik 
cmd> python sqlite_tk.py > out.txt
