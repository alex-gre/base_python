# Импорт библиотеки'
import sqlite3
 
conn = sqlite3.connect("employees.db")
cursor = conn.cursor()
    # Создание таблицы
cursor.execute('CREATE TABLE IF NOT EXISTS employee_data (emp_id  integer PRIMARY KEY AUTOINCREMENT,\
            f_name varchar(20),l_name varchar(20),title varchar(30),age int,yos int,salary int,perks int,email varchar(60))')
conn.commit()
     # Вводим данные
f_name = input('Enter First Name: ')
l_name = input('Enter Last Name: ')
title = input('Title: ')
age = int(input('Enter Age:'))
yos = int(input('Enter Yos:'))
salary = int(input('Enter Salary:'))
perks = int(input('Enter Perks:'))
email = input('Enter Email: ')
    # Вставляем данные в таблицу
cursor.execute('''INSERT INTO employee_data( f_name,l_name,title, age,yos,salary,perks,email) VALUES (?,?,?,?,?,?,?,?)''', (f_name, l_name,title,age,yos,salary,perks,email))
conn.commit()
    # Сохраняем изменения
conn.commit()
cursor.close()
conn.close()
