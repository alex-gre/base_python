# -*- coding: utf-8 -*-
import sqlite3
con = sqlite3.connect("catalog.db")
cur = con.cursor()               # Создаем объект-курсор
arr = [
         (1, 1, "http://wwwadmin.ru", "Название", "", 100),
         (1, 1, "http://python.org", "Python", "", 1000),
         (1, 3, "http://google.ru", "Гугль", "", 3000)
      ]
sql = """\
INSERT INTO site (id_user, id_rubr, url, title, msg, iq)
VALUES (?, ?, ?, ?, ?, ?)
"""
try:
    cur.executemany(sql, arr)
except sqlite3.DatabaseError as err:
    print("Ошибка:", err)
else:
    print("Запрос успешно выполнен")
    con.commit()                 # Завершаем транзакцию
cur.close()                      # Закрываем объект-курсор
con.close()                      # Закрываем соединение
input()
