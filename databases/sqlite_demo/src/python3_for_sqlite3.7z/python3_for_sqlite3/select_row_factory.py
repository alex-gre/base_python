# -*- coding: utf-8 -*-
import sqlite3
def my_factory(c, r):
    d = {}
    for i, name in enumerate(c.description):
        d[name[0]] = r[i] # Ключи в виде названий полей
        d[i] = r[i]       # Ключи в виде индексов полей
    return d

con = sqlite3.connect("catalog.db")
con.row_factory = my_factory
cur = con.cursor()        # Создаем объект-курсор
cur.execute("SELECT * FROM user")
arr = cur.fetchall()
print(arr)                 # Результат:
"""[{0: 1, 1: 'unicross@mail.ru', 2: 'password1', 'id_user': 1,
'passw': 'password1', 'email': 'unicross@mail.ru'}]"""
print(arr[0][1])          # Доступ по индексу
print(arr[0]["email"])    # Доступ но названию поля
cur.close()               # Закрываем объект-курсор
con.close()               # Закрываем соединение

