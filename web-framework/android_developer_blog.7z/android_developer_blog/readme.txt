﻿pip install flask
===============================
Create an environment
Create a project folder and a venv folder within:
> mkdir myproject
> cd myproject
> python -3 -m venv venv


C:\Users\User\PycharmProject\mywebserver>venv\Scripts\activate     "(activate venv)"

(venv) C:\Users\User\PycharmProject\mywebserver>pip freeze > requirements.txt

вернуться назад
deactivate